import json
import re
import csv

with open('positive-words.txt') as positiveWordFile:
    positiveWordList = [i.strip() for i in positiveWordFile.readlines()]

with open('negative-words.txt') as negativeWordFile:
    negativeWordList = [i.strip() for i in negativeWordFile.readlines()]

counter = 0
print(positiveWordList)
file = 'tweetList.json'
with open(file) as tweetsDump :
    data = json.load(tweetsDump)
    csvFile = open('tweetsFile.csv', 'w', newline='')
    csv_writer = csv.writer(csvFile , delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    csv_writer.writerow(['Tweet', 'Message/tweets', 'match', 'Polarity'])
    for tweet in data:
        positiveCounter = 0
        negativeCounter = 0
        positiveWords = []
        negativeWords = []
        wordBag = {}
        counter += 1
        text = tweet["text"]
        unicode_pattern = re.compile("["
                           u"\U0001F600-\U0001F64F"
                           u"\U0001F300-\U0001F5FF"
                           u"\U0001F680-\U0001F6FF"
                           u"\U0001F1E0-\U0001F1FF"
                           u"\U00002702-\U000027B0"
                           u"\U000024C2-\U0001F251"
                           "]+", flags=re.UNICODE)
        cleanText = unicode_pattern.sub(r'', text)
        cleanText = ''.join([char for char in cleanText if ord(char) < 128])
        cleanedText  = " ".join(re.sub("(\w+:\/\/\S+)", "", cleanText).split())
        print(str(counter) + cleanedText)
        print("*******************")
        words = cleanedText.split()
        uniqueWords = sorted(set(words))
        print(uniqueWords)
        for word in uniqueWords :
            wordBag[word] = cleanedText.count(word)
        for word in words :
            if positiveWordList.count(word.lower()) > 0:
                positiveWords.append(word.lower())
                positiveCounter += positiveWordList.count(word.lower())
            if negativeWordList.count(word) > 0 :
                negativeWords.append(word.lower())
                negativeCounter += negativeWordList.count(word)

        print(wordBag)
        #   print(str(positiveWords) + " " + str(positiveCounter))
        #   print(str(negativeWords) + " " + str(negativeCounter))
        if(positiveCounter > negativeCounter):
            print("Positive " + str(positiveWords))
            for positiveWord in positiveWords:
                csv_writer.writerow([str(counter), cleanedText, positiveWord, 'Positive'])
        elif (negativeCounter > positiveCounter):
            print("Negative " + str(negativeWords))
            for negativeWord in negativeWords:
                csv_writer.writerow([str(counter), cleanedText, negativeWord, 'Negative'])
        else:
            print("Neutral")
            csv_writer.writerow([str(counter), cleanedText, '', 'Neutral'])
    csvFile.close()
tweetsDump.close()


