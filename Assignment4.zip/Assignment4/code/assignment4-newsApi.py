import json
import os
import math
import re
import csv

counter = 0
tfidfFile = open('tf-idfFile.csv', 'w', newline='')
tfidfFileWriter = csv.writer(tfidfFile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
relFreqFile = open('relFreq.csv', 'w', newline='')
relFreqFileWriter = csv.writer(relFreqFile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

file = 'newsApiFinal.json'
with open(file) as newsDump :
    data = json.load(newsDump)
    for article in data :
        counter += 1
        del article["source"]
        del article["author"]
        del article["url"]
        del article["urlToImage"]
        del article["publishedAt"]

        articleTitle = article["title"]
        articleDesc = article["description"]
        articleContent = article["content"]
        unicode_pattern = re.compile("["
                                     u"\U0001F600-\U0001F64F"
                                     u"\U0001F300-\U0001F5FF"
                                     u"\U0001F680-\U0001F6FF"
                                     u"\U0001F1E0-\U0001F1FF"
                                     u"\U00002702-\U000027B0"
                                     u"\U000024C2-\U0001F251"
                                     "]+", flags=re.UNICODE)

        if articleTitle is not None:
            cleanArticleTitle = unicode_pattern.sub(r'', articleTitle)
            cleanArticleTitle = ''.join([char for char in cleanArticleTitle if ord(char) < 128])
            cleanArticleTitle = " ".join(re.sub("(\w+:\/\/\S+)", "", cleanArticleTitle).split())
            article["title"] = cleanArticleTitle

        if articleDesc is not None:
            cleanArticleDesc = unicode_pattern.sub(r'', articleDesc)
            cleanArticleDesc = ''.join([char for char in cleanArticleDesc if ord(char) < 128])
            cleanArticleDesc = " ".join(re.sub("(\w+:\/\/\S+)", "", cleanArticleDesc).split())
            article["description"] = cleanArticleDesc

        if articleContent is not None:
            cleanArticleContent = unicode_pattern.sub(r'', articleContent)
            cleanArticleContent = ''.join([char for char in cleanArticleContent if ord(char) < 128])
            cleanArticleContent = " ".join(re.sub("(\w+:\/\/\S+)", "", cleanArticleContent).split())
            article["content"] = cleanArticleContent
        # print(article)
        newsArticles = open(r"newsApi\newsArticleData" + str(counter) + ".json", "w+")
        json.dump(article, newsArticles, indent=4)
        newsArticles.close()
    newsDump.close()
#print(counter)
tfidfFileWriter.writerow(['Total Documents', counter, '', ''])
tfidfFileWriter.writerow(['', '', '', ''])
tfidfFileWriter.writerow(['Search Query', 'Document	containing term(df)',
                          'Total	 Documents(N)/	 number	of	 documents	 term	 appeared	(df)', 'Log10(N/df)'])
relFreqFileWriter.writerow(['Term ', 'Canada', ''])
relFreqFileWriter.writerow(['', '', ''])
relFreqFileWriter.writerow(['Document Name', 'Total Words (m)', 'Frequency (f)'])

fileCounter = 1
businessCtr, halifaxCtr, dalhousieUniversityCtr, canadaCtr, universityCtr = 0, 0, 0, 0, 0
businessNdf, halifaxNdf, dalhousieUniversityNdf, canadaNdf, universityNdf = 0.0, 0.0, 0.0, 0.0, 0.0
businessIdf, halifaxIdf, dalhousieUniversityIdf, canadaIdf, universityIdf = 0.0, 0.0, 0.0, 0.0, 0.0
relFreqMap = {}
folderPath = 'newsApi'
for file in os.listdir(folderPath) :
    filePath = folderPath + "/" + "newsArticleData" + str(fileCounter) + ".json"
    # print(filePath)
    fileName = "newsArticleData" + str(fileCounter) + ".json"
    fileOpen = open(folderPath + "/" + fileName)
    fileCounter += 1
    fileData = json.load(fileOpen)
    content = str(fileData)
    content = content.replace('-', ' ').replace('.', ' ').replace('\'', ' ')
    content = re.sub('[^a-zA-Z0-9 \n\.]', '', content)
    words = content.upper().split()

    if "CANADA" in words:
        canadaCtr += 1
        #print(words)
        totalWords = len(words)
        #    uniqueWords = sorted(set(words))
        canadaCount = words.count("CANADA")
        relFreq = canadaCount / totalWords
        #    print(fileName + ">>>>>>" + str(words.count("CANADA"))
        #          + " is the freq of the word CANADA in the file. Total words in the file  --"
        #          + str(totalWords) + "Relative Freq --- " + str(relFreq))
        relFreqMap[fileName] = relFreq
        relFreqFileWriter.writerow([fileName, totalWords, canadaCount])

    if "DALHOUSIE UNIVERSITY" in content.upper():
        dalhousieUniversityCtr += 1
    if "HALIFAX" in words:
        halifaxCtr += 1
    if "UNIVERSITY" in words:
        universityCtr += 1
    if "BUSINESS" in words:
        businessCtr += 1
    fileOpen.close()
# print(relFreqMap)
relFreqMapSorted = sorted(relFreqMap.items(), reverse=True, key=lambda x: x[1])
print(relFreqMapSorted[0])
fileToPrint = str(relFreqMapSorted[0]).split()[0]
fileToPrint = re.sub('[^a-zA-Z0-9 \n\.]', '', fileToPrint)
filePrint = open(folderPath + "/" + fileToPrint)
dataPrint = json.load(filePrint)
print(dataPrint)
filePrint.close()
#print(str(canadaCtr) + " " + str(dalhousieUniversityCtr) + " " + str(halifaxCtr) + " " + str(universityCtr) +
#      " " + str(businessCtr))

canadaNdf = round((counter / canadaCtr), 2)
halifaxNdf = round((counter / halifaxCtr), 2)
dalhousieUniversityNdf = round((counter / dalhousieUniversityCtr), 2)
businessNdf = round((counter / businessCtr), 2)
universityNdf = round((counter / universityCtr), 2)
# print(str(canadaNdf) + " " + str(dalhousieUniversityNdf) + " " + str(halifaxNdf) +
#      " " + str(universityNdf) + " " + str(businessNdf))
canadaIdf = round((math.log10(canadaNdf)), 2)
halifaxIdf = round((math.log10(halifaxNdf)), 2)
dalhousieUniversityIdf = round((math.log10(dalhousieUniversityNdf)), 2)
universityIdf = round((math.log10(universityNdf)), 2)
businessIdf = round((math.log10(businessNdf)), 2)
# print(str(canadaIdf) + " " + str(dalhousieUniversityIdf) + " " + str(halifaxIdf) +
#      " " + str(universityIdf) + " " + str(businessIdf))
tfidfFileWriter.writerow(['Canada', canadaCtr, str(counter) + "/" + str(canadaCtr) + "= " + str(canadaNdf), canadaIdf])
tfidfFileWriter.writerow(['Halifax', halifaxCtr, str(counter) + "/" + str(halifaxCtr) + "= " + str(halifaxNdf), halifaxIdf])
tfidfFileWriter.writerow(['Dalhousie University', dalhousieUniversityCtr, str(counter) + "/" + str(dalhousieUniversityCtr) + "= " + str(dalhousieUniversityNdf), dalhousieUniversityIdf])
tfidfFileWriter.writerow(['University', universityCtr, str(counter) + "/" + str(universityCtr) + "= " + str(universityNdf), universityIdf])
tfidfFileWriter.writerow(['Business', businessCtr, str(counter) + "/" + str(businessCtr) + "= " + str(businessNdf), businessIdf])
tfidfFile.close()
relFreqFile.close()

#https://thispointer.com/python-how-to-sort-a-dictionary-by-key-or-value/
#https://www.codementor.io/@isaib.cicourel/word-frequency-in-python-e7cyzy6l9